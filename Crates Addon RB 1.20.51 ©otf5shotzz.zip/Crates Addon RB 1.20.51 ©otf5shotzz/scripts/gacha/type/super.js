/*

░█████╗░██████╗░░█████╗░████████╗███████╗░██████╗
██╔══██╗██╔══██╗██╔══██╗╚══██╔══╝██╔════╝██╔════╝
██║░░╚═╝██████╔╝███████║░░░██║░░░█████╗░░╚█████╗░
██║░░██╗██╔══██╗██╔══██║░░░██║░░░██╔══╝░░░╚═══██╗
╚█████╔╝██║░░██║██║░░██║░░░██║░░░███████╗██████╔╝
░╚════╝░╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░╚══════╝╚═════╝░

░█████╗░██████╗░██████╗░░█████╗░███╗░░██╗
██╔══██╗██╔══██╗██╔══██╗██╔══██╗████╗░██║
███████║██║░░██║██║░░██║██║░░██║██╔██╗██║
██╔══██║██║░░██║██║░░██║██║░░██║██║╚████║
██║░░██║██████╔╝██████╔╝╚█████╔╝██║░╚███║
╚═╝░░╚═╝╚═════╝░╚═════╝░░╚════╝░╚═╝░░╚══╝                              

➊ 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡
Made by : AjayMC / @ajaytamfan
Version : 1.0
Official Website : www.ajaystudio.xyz
Discord Server : https://discord.com/invite/NNWf2CxtEY
        
➋ 𝗪𝗔𝗥𝗡
    English : Important Reminder Do not copy or plagiarize my additional code. 
    Appreciate other people's work and creativity. Get proper permissions before mixing it with other add-ons. 
    And if you want to translate the addon language into your language and publish it, 
    please provide the name of the original creator and tag the account @ajaytamfan in the description of your video

    Español : Recordatorio importante No copie ni plagie mi código adicional. 
    Apreciar el trabajo y la creatividad de los demás. Obtenga los permisos adecuados antes de mezclarlo con otros complementos. 
    Y si desea traducir el idioma del complemento a su idioma y publicarlo, mencione el nombre del creador original y etiquete la cuenta @ajaytamfan en la descripción de su video.

➌ 𝗛𝗢𝗪 𝗧𝗢 𝗔𝗗𝗗 𝗣𝗥𝗜𝗭𝗘
To add a prize, please follow the template below
    
    {
    displayName: "Diamond Cihuyy", //Display Name Here
    id: "minecraft:diamond", // Items Id Here
    quantity: 5, // Quantity Here
  },
  
  Additional Note: A Maximum Of 21 Prizes Can Be Added
  
❹  𝗦𝗣𝗘𝗖𝗜𝗔𝗟 𝗧𝗛𝗔𝗡𝗞𝗦
  Secial Thanks For 
  @Herobrine643928, @LeGend077, @Aex66 : Make Chest GUI
  @Snaky : Modifying The Chest Gui Texture
  
  © 2023 - 2023 www.ajaystudio.xyz - All Rights Reserved.
*/
const _0x4f43f8=_0x4ad5;function _0x4ad5(_0xd0a397,_0x26197f){const _0x58279c=_0x5827();return _0x4ad5=function(_0x4ad588,_0x48d4a8){_0x4ad588=_0x4ad588-0x12d;let _0x25b6bd=_0x58279c[_0x4ad588];return _0x25b6bd;},_0x4ad5(_0xd0a397,_0x26197f);}(function(_0x33185f,_0x4661d0){const _0x2cebbc=_0x4ad5,_0x421dcd=_0x33185f();while(!![]){try{const _0x587495=-parseInt(_0x2cebbc(0x134))/0x1*(parseInt(_0x2cebbc(0x130))/0x2)+parseInt(_0x2cebbc(0x16c))/0x3*(-parseInt(_0x2cebbc(0x172))/0x4)+-parseInt(_0x2cebbc(0x14a))/0x5+parseInt(_0x2cebbc(0x152))/0x6+-parseInt(_0x2cebbc(0x13c))/0x7*(parseInt(_0x2cebbc(0x148))/0x8)+parseInt(_0x2cebbc(0x16a))/0x9+-parseInt(_0x2cebbc(0x170))/0xa*(-parseInt(_0x2cebbc(0x142))/0xb);if(_0x587495===_0x4661d0)break;else _0x421dcd['push'](_0x421dcd['shift']());}catch(_0x518877){_0x421dcd['push'](_0x421dcd['shift']());}}}(_0x5827,0x618de));import{world,Player,system}from'@minecraft/server';import{ActionFormData,ModalFormData,MessageFormData}from'@minecraft/server-ui';import{getScore,prizesuper,pricesuper,formattedPriceSuper}from'../config.js';import{ChestFormData}from'../extensions/forms.js';let allowchestopen=!![],index=0x0,previousNameTag='';world[_0x4f43f8(0x141)]['entityHitEntity'][_0x4f43f8(0x161)](({damagingEntity:_0x48bae0,hitEntity:_0xc1f91c})=>{const _0x4d573f=_0x4f43f8;if(!(_0x48bae0 instanceof Player))return;if(_0xc1f91c[_0x4d573f(0x15e)]===_0x4d573f(0x12f)&&allowchestopen)gacha(_0x48bae0);else{if(_0xc1f91c[_0x4d573f(0x15e)]===_0x4d573f(0x12f)&&!allowchestopen){_0x48bae0[_0x4d573f(0x146)](_0x4d573f(0x12d));const _0x10faeb=_0x48bae0[_0x4d573f(0x14f)]();_0x48bae0[_0x4d573f(0x16d)](_0x10faeb['x'],_0x10faeb['z'],-0x2,0.3),_0x48bae0[_0x4d573f(0x175)]('note.bass',_0x48bae0[_0x4d573f(0x169)]);}}});const intervalHandler=system[_0x4f43f8(0x166)](()=>{const _0x4afa64=_0x4f43f8;for(const _0x58541e of world['getDimension'](_0x4afa64(0x158))[_0x4afa64(0x150)]()){if(_0x58541e[_0x4afa64(0x15e)]===_0x4afa64(0x12f)){if(allowchestopen)_0x58541e['nameTag']=_0x4afa64(0x140)+prizesuper[index][_0x4afa64(0x13a)]+_0x4afa64(0x157)+formattedPriceSuper;else _0x58541e[_0x4afa64(0x15a)]!==''&&(previousNameTag=_0x58541e['nameTag'],_0x58541e[_0x4afa64(0x15a)]='');}}index=(index+0x1)%prizesuper[_0x4afa64(0x159)];},0x14);function _0x5827(){const _0x59aed7=['§r§lprize\x20List\x0a§r§oView\x20prize','playSound','§c\x20Someone\x20else\x20is\x20opening\x20the\x20crate,\x20please\x20wait','forEach','crate:super','4eyaUBz','minecraft:coral_block','minecraft:lava','textures/ui/gacha/crate','390322HwSvRv','quantity','minecraft:water','www.ajaystudio.xyz','§r§7Super\x20Prize\x0a§r§oQuantity\x20:\x20','\x0a\x20§f\x0aWant\x20to\x20see\x20gacha\x20prize?\x0a\x20\x20Please\x20select\x20the\x20prize\x20list\x20menu\x0awant\x20to\x20open\x20crates?\x0a\x20select\x20the\x20open\x20crate\x20menu','displayName','runTimeout','400050zPHMAf','bars','minecraft:grass','minecraft:book','§l§d\x0a§r§o§7','afterEvents','4826657zYlCtG','then','§l§e','§c\x20The\x20crate\x20is\x20currently\x20being\x20opened\x20by\x20someone\x20else.\x20Please\x20wait.','sendMessage','minecraft:iron_bars','72toHTtl','§c\x20You\x20need\x20','1580995iuGbuN','runCommand','execute\x20at\x20@s\x20run\x20function\x20super','minecraft:seagrass','title','getViewDirection','getEntities','selection','2995434zhGXTU','leaves','floor','body','note.bass','\x0a§r§oprice\x20:\x20','minecraft:overworld','length','nameTag','give\x20','large','\x20§r','typeId','canceled','Click\x20to\x20exit\x20page.','subscribe','button','scoreboard',',\x20§dcongratulations!\x20§fYou\x27ve\x20got\x20§d','name','runInterval','minecraft:leaves','©ajaymc','location','5915718rfshnH','random','1563GFueQP','applyKnockback','money','textures/ui/icon_bookshelf','30AJWkvH','show','3548xBfbYx','addScore'];_0x5827=function(){return _0x59aed7;};return _0x5827();}function gacha(_0x2b2094){const _0x1aee19=_0x4f43f8;if(!allowchestopen){_0x2b2094[_0x1aee19(0x146)](_0x1aee19(0x145));return;}const _0x3c8fd7=new ActionFormData()['title']('{\x20-\x20Super\x20Crate\x20-\x20}')[_0x1aee19(0x155)](_0x1aee19(0x139))['button']('§r§lOpen\x20Crates\x0a§r§oPrice\x20:\x20'+formattedPriceSuper,_0x1aee19(0x133))[_0x1aee19(0x162)](_0x1aee19(0x174),_0x1aee19(0x16f));_0x3c8fd7['show'](_0x2b2094)[_0x1aee19(0x143)](_0x51bdb9=>{const _0x5a74b4=_0x1aee19;if(_0x51bdb9[_0x5a74b4(0x151)]===0x1)listprize(_0x2b2094);if(_0x51bdb9['selection']===0x0&&allowchestopen){if(getScore(_0x5a74b4(0x16e),_0x2b2094)>=pricesuper)_0x2b2094['addTag']('opename'),_0x2b2094['runCommand'](_0x5a74b4(0x14c)),allowchestopen=![],GC(_0x2b2094);else{_0x2b2094[_0x5a74b4(0x146)](_0x5a74b4(0x149)+formattedPriceSuper+'\x20to\x20open\x20the\x20crate');const _0x54e31d=_0x2b2094['getViewDirection']();_0x2b2094[_0x5a74b4(0x16d)](_0x54e31d['x'],_0x54e31d['z'],-0x2,0.3),_0x2b2094[_0x5a74b4(0x175)](_0x5a74b4(0x156),_0x2b2094['location']);}}});}function listprize(_0x45ab0a){const _0x15bb9c=_0x4f43f8,_0x4ecdd9=new ChestFormData(_0x15bb9c(0x15c))[_0x15bb9c(0x14e)]('\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20Super\x20Crates');_0x4ecdd9[_0x15bb9c(0x162)](0xd,'§cBack',[_0x15bb9c(0x160)],_0x15bb9c(0x13f),0x1,!![]);const _0x4c470b={'leaves':_0x15bb9c(0x136),'bars':_0x15bb9c(0x14d),'grass':_0x15bb9c(0x131)},_0x512d63={'leaves':_0x15bb9c(0x167),'bars':_0x15bb9c(0x147),'grass':_0x15bb9c(0x13e)},_0x4829cd={'leaves':_0x15bb9c(0x132),'bars':'minecraft:iron_bars','grass':'minecraft:nether_brick'},_0x43f4bc=Math[_0x15bb9c(0x16b)]();let _0x21877b;if(_0x43f4bc<0.33)_0x21877b=_0x4c470b;else _0x43f4bc<0.66?_0x21877b=_0x512d63:_0x21877b=_0x4829cd;const _0xfa334f=[0x0,0x1,0x2,0x3,0x4,0x5,0x6,0x7,0x8,0x9,0x11,0x12,0x1a,0x1b,0x23,0x24,0x2c];_0xfa334f[_0x15bb9c(0x12e)](_0x2b9074=>_0x4ecdd9[_0x15bb9c(0x162)](_0x2b9074,_0x15bb9c(0x168),[_0x15bb9c(0x137)],_0x21877b[_0x15bb9c(0x153)]));const _0x167d25=[0xa,0xb,0xc,0xe,0xf,0x10];_0x167d25['forEach'](_0x57ed37=>_0x4ecdd9[_0x15bb9c(0x162)](_0x57ed37,_0x15bb9c(0x168),['www.ajaystudio.xyz'],_0x21877b[_0x15bb9c(0x13d)]));const _0x5bbb2a=[0x2d,0x2e,0x2f,0x30,0x31,0x32,0x33,0x34,0x35];_0x5bbb2a[_0x15bb9c(0x12e)](_0x3839e0=>_0x4ecdd9[_0x15bb9c(0x162)](_0x3839e0,_0x15bb9c(0x168),[_0x15bb9c(0x137)],_0x21877b['grass']));let _0x3fe864=0x13;prizesuper[_0x15bb9c(0x12e)]((_0x59ebae,_0x5a52b1)=>{const _0x476aa3=_0x15bb9c;if(_0x3fe864<=0x19)_0x4ecdd9[_0x476aa3(0x162)](_0x3fe864++,_0x476aa3(0x144)+_0x59ebae[_0x476aa3(0x13a)],[_0x476aa3(0x138)+_0x59ebae[_0x476aa3(0x135)]+'x'],''+_0x59ebae['id'],''+_0x59ebae[_0x476aa3(0x135)]);else{if(_0x3fe864<=0x22)_0x3fe864=0x1c,_0x4ecdd9[_0x476aa3(0x162)](_0x3fe864++,_0x476aa3(0x144)+_0x59ebae['displayName'],[_0x476aa3(0x138)+_0x59ebae[_0x476aa3(0x135)]+'x'],''+_0x59ebae['id'],''+_0x59ebae[_0x476aa3(0x135)]);else _0x3fe864<=0x2b&&(_0x3fe864=0x25,_0x4ecdd9[_0x476aa3(0x162)](_0x3fe864++,_0x476aa3(0x144)+_0x59ebae['displayName'],[_0x476aa3(0x138)+_0x59ebae[_0x476aa3(0x135)]+'x'],''+_0x59ebae['id'],''+_0x59ebae[_0x476aa3(0x135)]));}}),_0x4ecdd9[_0x15bb9c(0x171)](_0x45ab0a)[_0x15bb9c(0x143)](_0xe52016=>{const _0x336a01=_0x15bb9c;if(_0xe52016[_0x336a01(0x15f)])return;if(_0xe52016[_0x336a01(0x151)]===0xd)return gacha(_0x45ab0a);});}function GC(_0x2829bd){const _0x3e8012=_0x4f43f8,_0x24d358=getScore(_0x3e8012(0x16e),_0x2829bd);_0x24d358>=pricesuper&&(world[_0x3e8012(0x163)]['getObjective'](_0x3e8012(0x16e))[_0x3e8012(0x173)](_0x2829bd,-pricesuper),system[_0x3e8012(0x13b)](()=>{const _0x361ec3=_0x3e8012,_0x4b0478=Math[_0x361ec3(0x154)](Math[_0x361ec3(0x16b)]()*prizesuper['length']),_0x2a2137=prizesuper[_0x4b0478];_0x2829bd[_0x361ec3(0x14b)](_0x361ec3(0x15b)+_0x2829bd[_0x361ec3(0x165)]+'\x20'+_0x2a2137['id']+'\x20'+_0x2a2137[_0x361ec3(0x135)]),_0x2829bd[_0x361ec3(0x146)](_0x361ec3(0x15d)+_0x2829bd[_0x361ec3(0x165)]+_0x361ec3(0x164)+_0x2a2137['displayName']+'.'),_0x2829bd[_0x361ec3(0x175)]('random.fizz',_0x2829bd[_0x361ec3(0x169)]),allowchestopen=!![];},0x4b));}