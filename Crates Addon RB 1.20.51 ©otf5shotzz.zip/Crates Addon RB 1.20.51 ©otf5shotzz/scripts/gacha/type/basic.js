/*

░█████╗░██████╗░░█████╗░████████╗███████╗░██████╗
██╔══██╗██╔══██╗██╔══██╗╚══██╔══╝██╔════╝██╔════╝
██║░░╚═╝██████╔╝███████║░░░██║░░░█████╗░░╚█████╗░
██║░░██╗██╔══██╗██╔══██║░░░██║░░░██╔══╝░░░╚═══██╗
╚█████╔╝██║░░██║██║░░██║░░░██║░░░███████╗██████╔╝
░╚════╝░╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░╚══════╝╚═════╝░

░█████╗░██████╗░██████╗░░█████╗░███╗░░██╗
██╔══██╗██╔══██╗██╔══██╗██╔══██╗████╗░██║
███████║██║░░██║██║░░██║██║░░██║██╔██╗██║
██╔══██║██║░░██║██║░░██║██║░░██║██║╚████║
██║░░██║██████╔╝██████╔╝╚█████╔╝██║░╚███║
╚═╝░░╚═╝╚═════╝░╚═════╝░░╚════╝░╚═╝░░╚══╝                              

➊ 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡
Made by : AjayMC / @ajaytamfan
Version : 1.0
Official Website : www.ajaystudio.xyz
Discord Server : https://discord.com/invite/NNWf2CxtEY
        
➋ 𝗪𝗔𝗥𝗡
    English : Important Reminder Do not copy or plagiarize my additional code. 
    Appreciate other people's work and creativity. Get proper permissions before mixing it with other add-ons. 
    And if you want to translate the addon language into your language and publish it, 
    please provide the name of the original creator and tag the account @ajaytamfan in the description of your video

    Español : Recordatorio importante No copie ni plagie mi código adicional. 
    Apreciar el trabajo y la creatividad de los demás. Obtenga los permisos adecuados antes de mezclarlo con otros complementos. 
    Y si desea traducir el idioma del complemento a su idioma y publicarlo, mencione el nombre del creador original y etiquete la cuenta @ajaytamfan en la descripción de su video.

➌ 𝗛𝗢𝗪 𝗧𝗢 𝗔𝗗𝗗 𝗣𝗥𝗜𝗭𝗘
To add a prize, please follow the template below
    
    {
    displayName: "Diamond Cihuyy", //Display Name Here
    id: "minecraft:diamond", // Items Id Here
    quantity: 5, // Quantity Here
  },
  
  Additional Note: A Maximum Of 21 Prizes Can Be Added
  
❹  𝗦𝗣𝗘𝗖𝗜𝗔𝗟 𝗧𝗛𝗔𝗡𝗞𝗦
  Secial Thanks For 
  @Herobrine643928, @LeGend077, @Aex66 : Make Chest GUI
  @Snaky : Modifying The Chest Gui Texture
  
  © 2023 - 2023 www.ajaystudio.xyz - All Rights Reserved.
*/

const _0x339623=_0x25e6;(function(_0x27e8c9,_0xace7b){const _0x3b8ede=_0x25e6,_0x25d87a=_0x27e8c9();while(!![]){try{const _0x2fbc7b=-parseInt(_0x3b8ede(0x182))/0x1*(-parseInt(_0x3b8ede(0x175))/0x2)+parseInt(_0x3b8ede(0x1ab))/0x3*(parseInt(_0x3b8ede(0x196))/0x4)+parseInt(_0x3b8ede(0x17f))/0x5*(-parseInt(_0x3b8ede(0x189))/0x6)+-parseInt(_0x3b8ede(0x17c))/0x7*(-parseInt(_0x3b8ede(0x1a4))/0x8)+parseInt(_0x3b8ede(0x194))/0x9+parseInt(_0x3b8ede(0x179))/0xa*(-parseInt(_0x3b8ede(0x187))/0xb)+-parseInt(_0x3b8ede(0x190))/0xc;if(_0x2fbc7b===_0xace7b)break;else _0x25d87a['push'](_0x25d87a['shift']());}catch(_0x4da416){_0x25d87a['push'](_0x25d87a['shift']());}}}(_0x51ae,0x60d8c));import{world,Player,system}from'@minecraft/server';function _0x51ae(){const _0x44c5cf=['minecraft:book','forEach','§c\x20You\x20need\x20','270468KEKAPa','location','4bWoBru','nameTag','§r§lOpen\x20Crates\x0a§r§oPrice\x20:\x20','crate:basic','money','minecraft:leaves','©ajaymc','random','note.bass','quantity','execute\x20at\x20@s\x20run\x20function\x20basic','textures/ui/gacha/crate','show','scoreboard','8lFMOvj','minecraft:lava','name','applyKnockback','sendMessage','button','playSound','1718028NLfUpP','{\x20-\x20Basic\x20Crate\x20-\x20}','runInterval','getViewDirection','minecraft:overworld','typeId','canceled','random.fizz','length','subscribe','give\x20','grass','www.ajaystudio.xyz','afterEvents','large','§l§b\x0a§r§o§7','2yrePzh','§cBack',',\x20§bcongratulations!\x20§fYou\x27ve\x20got\x20§b','leaves','10AHsiex','minecraft:coral_block','Click\x20to\x20exit\x20page.','673043AJseqm','addTag','entityHitEntity','4780mewkXh','minecraft:iron_bars','§r§7Basic\x20Prize\x0a§r§oQuantity\x20:\x20','57158ayMFEn','displayName','§c\x20Someone\x20else\x20is\x20opening\x20the\x20crate,\x20please\x20wait','§l§e','getDimension','869033CIIldx','runCommand','1164TKYqaM','then','minecraft:seagrass','\x20to\x20open\x20the\x20crate','\x0a\x20§f\x0aWant\x20to\x20see\x20gacha\x20prize?\x0a\x20\x20Please\x20select\x20the\x20prize\x20list\x20menu\x0awant\x20to\x20open\x20crates?\x0a\x20select\x20the\x20open\x20crate\x20menu','selection','§r§lprize\x20List\x0a§r§oView\x20prize','1138608RUIbYT'];_0x51ae=function(){return _0x44c5cf;};return _0x51ae();}import{ActionFormData,ModalFormData,MessageFormData}from'@minecraft/server-ui';import{prizebasic,pricebasic,getScore,formattedPriceBasic}from'../config.js';function _0x25e6(_0x2c64a2,_0x4b414b){const _0x51aeda=_0x51ae();return _0x25e6=function(_0x25e61f,_0x4b6e57){_0x25e61f=_0x25e61f-0x16e;let _0x3b088b=_0x51aeda[_0x25e61f];return _0x3b088b;},_0x25e6(_0x2c64a2,_0x4b414b);}import{ChestFormData}from'../extensions/forms.js';let allowchestopen=!![],index=0x0,previousNameTag='';world[_0x339623(0x172)][_0x339623(0x17e)][_0x339623(0x16e)](({damagingEntity:_0x304414,hitEntity:_0x1e3b87})=>{const _0x101d35=_0x339623;if(!(_0x304414 instanceof Player))return;if(_0x1e3b87[_0x101d35(0x1b0)]==='crate:basic'&&allowchestopen)gacha(_0x304414);else{if(_0x1e3b87[_0x101d35(0x1b0)]===_0x101d35(0x199)&&!allowchestopen){_0x304414['sendMessage'](_0x101d35(0x184));const _0x2b1287=_0x304414[_0x101d35(0x1ae)]();_0x304414['applyKnockback'](_0x2b1287['x'],_0x2b1287['z'],-0x2,0.3),_0x304414['playSound'](_0x101d35(0x19e),_0x304414['location']);}}});const intervalHandler=system[_0x339623(0x1ad)](()=>{const _0x5863d3=_0x339623;for(const _0x2c7807 of world[_0x5863d3(0x186)](_0x5863d3(0x1af))['getEntities']()){if(_0x2c7807['typeId']===_0x5863d3(0x199)){if(allowchestopen)_0x2c7807[_0x5863d3(0x197)]=_0x5863d3(0x174)+prizebasic[index][_0x5863d3(0x183)]+'\x0a§r§oprice\x20:\x20'+formattedPriceBasic;else _0x2c7807[_0x5863d3(0x197)]!==''&&(previousNameTag=_0x2c7807['nameTag'],_0x2c7807[_0x5863d3(0x197)]='');}}index=(index+0x1)%prizebasic[_0x5863d3(0x1b3)];},0x14);function gacha(_0x176992){const _0x3ea018=_0x339623;if(!allowchestopen){_0x176992['sendMessage']('§c\x20The\x20crate\x20is\x20currently\x20being\x20opened\x20by\x20someone\x20else.\x20Please\x20wait.');return;}const _0x35ec8b=new ActionFormData()['title'](_0x3ea018(0x1ac))['body'](_0x3ea018(0x18d))[_0x3ea018(0x1a9)](_0x3ea018(0x198)+formattedPriceBasic,_0x3ea018(0x1a1))[_0x3ea018(0x1a9)](_0x3ea018(0x18f),'textures/ui/icon_bookshelf');_0x35ec8b[_0x3ea018(0x1a2)](_0x176992)[_0x3ea018(0x18a)](_0x1f34b9=>{const _0xce384a=_0x3ea018;if(_0x1f34b9[_0xce384a(0x18e)]===0x1)listprize(_0x176992);if(_0x1f34b9[_0xce384a(0x18e)]===0x0&&allowchestopen){if(getScore(_0xce384a(0x19a),_0x176992)>=pricebasic)_0x176992[_0xce384a(0x17d)]('openbasic'),_0x176992[_0xce384a(0x188)](_0xce384a(0x1a0)),allowchestopen=![],GC(_0x176992);else{_0x176992[_0xce384a(0x1a8)](_0xce384a(0x193)+formattedPriceBasic+_0xce384a(0x18c));const _0x5efc2a=_0x176992[_0xce384a(0x1ae)]();_0x176992[_0xce384a(0x1a7)](_0x5efc2a['x'],_0x5efc2a['z'],-0x2,0.3),_0x176992[_0xce384a(0x1aa)](_0xce384a(0x19e),_0x176992[_0xce384a(0x195)]);}}});}function listprize(_0x50f0ac){const _0x58709f=_0x339623,_0x3e90c0=new ChestFormData(_0x58709f(0x173))['title']('\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20Basic\x20Crates');_0x3e90c0[_0x58709f(0x1a9)](0xd,_0x58709f(0x176),[_0x58709f(0x17b)],_0x58709f(0x191),0x1,!![]);const _0x3a3821={'leaves':'minecraft:water','bars':_0x58709f(0x18b),'grass':_0x58709f(0x17a)},_0x2c0dfa={'leaves':_0x58709f(0x19b),'bars':_0x58709f(0x180),'grass':'minecraft:grass'},_0x209a13={'leaves':_0x58709f(0x1a5),'bars':'minecraft:iron_bars','grass':'minecraft:nether_brick'},_0x52824c=Math[_0x58709f(0x19d)]();let _0x5071e6;if(_0x52824c<0.33)_0x5071e6=_0x3a3821;else _0x52824c<0.66?_0x5071e6=_0x2c0dfa:_0x5071e6=_0x209a13;const _0x1e5181=[0x0,0x1,0x2,0x3,0x4,0x5,0x6,0x7,0x8,0x9,0x11,0x12,0x1a,0x1b,0x23,0x24,0x2c];_0x1e5181['forEach'](_0x3b9a2e=>_0x3e90c0[_0x58709f(0x1a9)](_0x3b9a2e,_0x58709f(0x19c),[_0x58709f(0x171)],_0x5071e6[_0x58709f(0x178)]));const _0x39a1db=[0xa,0xb,0xc,0xe,0xf,0x10];_0x39a1db[_0x58709f(0x192)](_0xaf3f0c=>_0x3e90c0[_0x58709f(0x1a9)](_0xaf3f0c,_0x58709f(0x19c),[_0x58709f(0x171)],_0x5071e6['bars']));const _0x1b1f4e=[0x2d,0x2e,0x2f,0x30,0x31,0x32,0x33,0x34,0x35];_0x1b1f4e[_0x58709f(0x192)](_0x3312c6=>_0x3e90c0[_0x58709f(0x1a9)](_0x3312c6,'©ajaymc',['www.ajaystudio.xyz'],_0x5071e6[_0x58709f(0x170)]));let _0x49827c=0x13;prizebasic[_0x58709f(0x192)]((_0x51b1aa,_0x4f288c)=>{const _0x281392=_0x58709f;if(_0x49827c<=0x19)_0x3e90c0['button'](_0x49827c++,_0x281392(0x185)+_0x51b1aa['displayName'],[_0x281392(0x181)+_0x51b1aa[_0x281392(0x19f)]+'x'],''+_0x51b1aa['id'],''+_0x51b1aa[_0x281392(0x19f)]);else{if(_0x49827c<=0x22)_0x49827c=0x1c,_0x3e90c0[_0x281392(0x1a9)](_0x49827c++,_0x281392(0x185)+_0x51b1aa[_0x281392(0x183)],['§r§7Basic\x20Prize\x0a§r§oQuantity\x20:\x20'+_0x51b1aa[_0x281392(0x19f)]+'x'],''+_0x51b1aa['id'],''+_0x51b1aa[_0x281392(0x19f)]);else _0x49827c<=0x2b&&(_0x49827c=0x25,_0x3e90c0['button'](_0x49827c++,'§l§e'+_0x51b1aa['displayName'],[_0x281392(0x181)+_0x51b1aa[_0x281392(0x19f)]+'x'],''+_0x51b1aa['id'],''+_0x51b1aa[_0x281392(0x19f)]));}}),_0x3e90c0['show'](_0x50f0ac)[_0x58709f(0x18a)](_0xcfd2a5=>{const _0x43c826=_0x58709f;if(_0xcfd2a5[_0x43c826(0x1b1)])return;if(_0xcfd2a5[_0x43c826(0x18e)]===0xd)return gacha(_0x50f0ac);});}function GC(_0x3b0a44){const _0x1375fc=_0x339623,_0x3664f4=getScore(_0x1375fc(0x19a),_0x3b0a44);_0x3664f4>=pricebasic&&(world[_0x1375fc(0x1a3)]['getObjective']('money')['addScore'](_0x3b0a44,-pricebasic),system['runTimeout'](()=>{const _0x5388f1=_0x1375fc,_0xead3cb=Math['floor'](Math['random']()*prizebasic[_0x5388f1(0x1b3)]),_0x3bd9d3=prizebasic[_0xead3cb];_0x3b0a44[_0x5388f1(0x188)](_0x5388f1(0x16f)+_0x3b0a44[_0x5388f1(0x1a6)]+'\x20'+_0x3bd9d3['id']+'\x20'+_0x3bd9d3[_0x5388f1(0x19f)]),_0x3b0a44['sendMessage']('\x20§r'+_0x3b0a44['name']+_0x5388f1(0x177)+_0x3bd9d3[_0x5388f1(0x183)]+'.'),_0x3b0a44[_0x5388f1(0x1aa)](_0x5388f1(0x1b2),_0x3b0a44[_0x5388f1(0x195)]),allowchestopen=!![];},0x4b));}