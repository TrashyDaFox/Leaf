/*

░█████╗░██████╗░░█████╗░████████╗███████╗░██████╗
██╔══██╗██╔══██╗██╔══██╗╚══██╔══╝██╔════╝██╔════╝
██║░░╚═╝██████╔╝███████║░░░██║░░░█████╗░░╚█████╗░
██║░░██╗██╔══██╗██╔══██║░░░██║░░░██╔══╝░░░╚═══██╗
╚█████╔╝██║░░██║██║░░██║░░░██║░░░███████╗██████╔╝
░╚════╝░╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░╚══════╝╚═════╝░

░█████╗░██████╗░██████╗░░█████╗░███╗░░██╗
██╔══██╗██╔══██╗██╔══██╗██╔══██╗████╗░██║
███████║██║░░██║██║░░██║██║░░██║██╔██╗██║
██╔══██║██║░░██║██║░░██║██║░░██║██║╚████║
██║░░██║██████╔╝██████╔╝╚█████╔╝██║░╚███║
╚═╝░░╚═╝╚═════╝░╚═════╝░░╚════╝░╚═╝░░╚══╝                              

➊ 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡
Made by : AjayMC / @ajaytamfan
Version : 1.0
Official Website : www.ajaystudio.xyz
Discord Server : https://discord.com/invite/NNWf2CxtEY
        
➋ 𝗪𝗔𝗥𝗡
    English : Important Reminder Do not copy or plagiarize my additional code. 
    Appreciate other people's work and creativity. Get proper permissions before mixing it with other add-ons. 
    And if you want to translate the addon language into your language and publish it, 
    please provide the name of the original creator and tag the account @ajaytamfan in the description of your video

    Español : Recordatorio importante No copie ni plagie mi código adicional. 
    Apreciar el trabajo y la creatividad de los demás. Obtenga los permisos adecuados antes de mezclarlo con otros complementos. 
    Y si desea traducir el idioma del complemento a su idioma y publicarlo, mencione el nombre del creador original y etiquete la cuenta @ajaytamfan en la descripción de su video.

➌ 𝗛𝗢𝗪 𝗧𝗢 𝗔𝗗𝗗 𝗣𝗥𝗜𝗭𝗘
To add a prize, please follow the template below
    
    {
    displayName: "Diamond Cihuyy", //Display Name Here
    id: "minecraft:diamond", // Items Id Here
    quantity: 5, // Quantity Here
  },
  
  Additional Note: A Maximum Of 21 Prizes Can Be Added
  
❹  𝗦𝗣𝗘𝗖𝗜𝗔𝗟 𝗧𝗛𝗔𝗡𝗞𝗦
  Secial Thanks For 
  @Herobrine643928, @LeGend077, @Aex66 : Make Chest GUI
  @Snaky : Modifying The Chest Gui Texture
  
  © 2023 - 2023 www.ajaystudio.xyz - All Rights Reserved.
*/
const _0x1b3781=_0x2808;(function(_0x1399fa,_0x27e21d){const _0x223206=_0x2808,_0x5f1d48=_0x1399fa();while(!![]){try{const _0x46cf98=parseInt(_0x223206(0x97))/0x1+parseInt(_0x223206(0x9f))/0x2+parseInt(_0x223206(0x95))/0x3*(-parseInt(_0x223206(0xbd))/0x4)+parseInt(_0x223206(0xb6))/0x5+parseInt(_0x223206(0x87))/0x6+-parseInt(_0x223206(0x82))/0x7+-parseInt(_0x223206(0x93))/0x8*(-parseInt(_0x223206(0x86))/0x9);if(_0x46cf98===_0x27e21d)break;else _0x5f1d48['push'](_0x5f1d48['shift']());}catch(_0xec9061){_0x5f1d48['push'](_0x5f1d48['shift']());}}}(_0x3c11,0x2bc5f));function _0x3c11(){const _0x218347=['getEntities','§cBack','475660pqJMgV','minecraft:leaves','\x20to\x20open\x20the\x20crate','note.bass','runInterval','§l§6\x0a§r§o§7','{\x20-\x20Rare\x20Crate\x20-\x20}','playSound','©ajaymc','§c\x20The\x20crate\x20is\x20currently\x20being\x20opened\x20by\x20someone\x20else.\x20Please\x20wait.','then','minecraft:iron_bars','crate:rare','1970038TfYBRf','title','§r§lprize\x20List\x0a§r§oView\x20prize','body','188109IhwvaX','1254054VgDIbq','§r§7Rare\x20Prize\x0a§r§oQuantity\x20:\x20','displayName','§c\x20Someone\x20else\x20is\x20opening\x20the\x20crate,\x20please\x20wait','getDimension','§l§e','openrare','getViewDirection','floor','sendMessage','addScore',',\x20§6congratulations!\x20§fYou\x27ve\x20got\x20§6','8TfKHht','minecraft:seagrass','9JSgpkS','quantity','114698hbbvVq','minecraft:book','forEach','minecraft:lava','textures/ui/icon_bookshelf','entityHitEntity','afterEvents','selection','267364QHfWoV','addTag','show','getObjective','applyKnockback','minecraft:coral_block','random','textures/ui/gacha/crate','button','length','§c\x20You\x20need\x20','typeId','\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20Rare\x20Crates','location','random.fizz','\x20§r','\x0a\x20§f\x0aWant\x20to\x20see\x20gacha\x20prize?\x0a\x20\x20Please\x20select\x20the\x20prize\x20list\x20menu\x0awant\x20to\x20open\x20crates?\x0a\x20select\x20the\x20open\x20crate\x20menu','name','nameTag','runCommand','subscribe','large','www.ajaystudio.xyz','1695920kLHZjx','money','§r§lOpen\x20Crates\x0a§r§oPrice\x20:\x20','runTimeout','give\x20'];_0x3c11=function(){return _0x218347;};return _0x3c11();}import{world,Player,system}from'@minecraft/server';import{ActionFormData,ModalFormData,MessageFormData}from'@minecraft/server-ui';import{getScore,prizerare,formattedPriceRare,pricerare}from'../config.js';import{ChestFormData}from'../extensions/forms.js';let allowchestopen=!![],index=0x0,previousNameTag='';world[_0x1b3781(0x9d)][_0x1b3781(0x9c)][_0x1b3781(0xb3)](({damagingEntity:_0x5c05de,hitEntity:_0x283786})=>{const _0x130cc6=_0x1b3781;if(!(_0x5c05de instanceof Player))return;if(_0x283786[_0x130cc6(0xaa)]===_0x130cc6(0x81)&&allowchestopen)gacha(_0x5c05de);else{if(_0x283786[_0x130cc6(0xaa)]===_0x130cc6(0x81)&&!allowchestopen){_0x5c05de['sendMessage'](_0x130cc6(0x8a));const _0x232e18=_0x5c05de[_0x130cc6(0x8e)]();_0x5c05de[_0x130cc6(0xa3)](_0x232e18['x'],_0x232e18['z'],-0x2,0.3),_0x5c05de[_0x130cc6(0xc4)](_0x130cc6(0xc0),_0x5c05de['location']);}}});const intervalHandler=system[_0x1b3781(0xc1)](()=>{const _0x56a9c5=_0x1b3781;for(const _0x58ec82 of world[_0x56a9c5(0x8b)]('minecraft:overworld')[_0x56a9c5(0xbb)]()){if(_0x58ec82['typeId']===_0x56a9c5(0x81)){if(allowchestopen)_0x58ec82[_0x56a9c5(0xb1)]=_0x56a9c5(0xc2)+prizerare[index][_0x56a9c5(0x89)]+'\x0a§r§oprice\x20:\x20'+formattedPriceRare;else _0x58ec82['nameTag']!==''&&(previousNameTag=_0x58ec82[_0x56a9c5(0xb1)],_0x58ec82['nameTag']='');}}index=(index+0x1)%prizerare[_0x56a9c5(0xa8)];},0x14);function gacha(_0x488e05){const _0x3b8038=_0x1b3781;if(!allowchestopen){_0x488e05[_0x3b8038(0x90)](_0x3b8038(0xc6));return;}const _0x5269e1=new ActionFormData()[_0x3b8038(0x83)](_0x3b8038(0xc3))[_0x3b8038(0x85)](_0x3b8038(0xaf))[_0x3b8038(0xa7)](_0x3b8038(0xb8)+formattedPriceRare,_0x3b8038(0xa6))[_0x3b8038(0xa7)](_0x3b8038(0x84),_0x3b8038(0x9b));_0x5269e1[_0x3b8038(0xa1)](_0x488e05)[_0x3b8038(0xc7)](_0x1f8625=>{const _0x4ebf95=_0x3b8038;if(_0x1f8625[_0x4ebf95(0x9e)]===0x1)listprize(_0x488e05);if(_0x1f8625[_0x4ebf95(0x9e)]===0x0&&allowchestopen){if(getScore(_0x4ebf95(0xb7),_0x488e05)>=pricerare)_0x488e05[_0x4ebf95(0xa0)](_0x4ebf95(0x8d)),_0x488e05[_0x4ebf95(0xb2)]('execute\x20at\x20@s\x20run\x20function\x20rare'),allowchestopen=![],GC(_0x488e05);else{_0x488e05['sendMessage'](_0x4ebf95(0xa9)+formattedPriceRare+_0x4ebf95(0xbf));const _0x38e51a=_0x488e05[_0x4ebf95(0x8e)]();_0x488e05[_0x4ebf95(0xa3)](_0x38e51a['x'],_0x38e51a['z'],-0x2,0.3),_0x488e05[_0x4ebf95(0xc4)](_0x4ebf95(0xc0),_0x488e05[_0x4ebf95(0xac)]);}}});}function listprize(_0x152312){const _0x5ac805=_0x1b3781,_0xa5d226=new ChestFormData(_0x5ac805(0xb4))[_0x5ac805(0x83)](_0x5ac805(0xab));_0xa5d226[_0x5ac805(0xa7)](0xd,_0x5ac805(0xbc),['Click\x20to\x20exit\x20page.'],_0x5ac805(0x98),0x1,!![]);const _0x37a156={'leaves':'minecraft:water','bars':_0x5ac805(0x94),'grass':_0x5ac805(0xa4)},_0x3c42e8={'leaves':_0x5ac805(0xbe),'bars':'minecraft:iron_bars','grass':'minecraft:grass'},_0x25c5d3={'leaves':_0x5ac805(0x9a),'bars':_0x5ac805(0x80),'grass':'minecraft:nether_brick'},_0x3a3a4b=Math[_0x5ac805(0xa5)]();let _0x1f2ff2;if(_0x3a3a4b<0.33)_0x1f2ff2=_0x37a156;else _0x3a3a4b<0.66?_0x1f2ff2=_0x3c42e8:_0x1f2ff2=_0x25c5d3;const _0x5bae16=[0x0,0x1,0x2,0x3,0x4,0x5,0x6,0x7,0x8,0x9,0x11,0x12,0x1a,0x1b,0x23,0x24,0x2c];_0x5bae16[_0x5ac805(0x99)](_0x1e39d0=>_0xa5d226[_0x5ac805(0xa7)](_0x1e39d0,_0x5ac805(0xc5),[_0x5ac805(0xb5)],_0x1f2ff2['leaves']));const _0x529712=[0xa,0xb,0xc,0xe,0xf,0x10];_0x529712[_0x5ac805(0x99)](_0x2b8a80=>_0xa5d226[_0x5ac805(0xa7)](_0x2b8a80,_0x5ac805(0xc5),['www.ajaystudio.xyz'],_0x1f2ff2['bars']));const _0x2d4f0f=[0x2d,0x2e,0x2f,0x30,0x31,0x32,0x33,0x34,0x35];_0x2d4f0f['forEach'](_0x581e20=>_0xa5d226[_0x5ac805(0xa7)](_0x581e20,'©ajaymc',[_0x5ac805(0xb5)],_0x1f2ff2['grass']));let _0x408eec=0x13;prizerare[_0x5ac805(0x99)]((_0xb07d,_0x269e1b)=>{const _0x39dbd4=_0x5ac805;if(_0x408eec<=0x19)_0xa5d226[_0x39dbd4(0xa7)](_0x408eec++,_0x39dbd4(0x8c)+_0xb07d[_0x39dbd4(0x89)],[_0x39dbd4(0x88)+_0xb07d[_0x39dbd4(0x96)]+'x'],''+_0xb07d['id'],''+_0xb07d['quantity']);else{if(_0x408eec<=0x22)_0x408eec=0x1c,_0xa5d226['button'](_0x408eec++,'§l§e'+_0xb07d[_0x39dbd4(0x89)],[_0x39dbd4(0x88)+_0xb07d[_0x39dbd4(0x96)]+'x'],''+_0xb07d['id'],''+_0xb07d['quantity']);else _0x408eec<=0x2b&&(_0x408eec=0x25,_0xa5d226['button'](_0x408eec++,_0x39dbd4(0x8c)+_0xb07d[_0x39dbd4(0x89)],['§r§7Rare\x20Prize\x0a§r§oQuantity\x20:\x20'+_0xb07d['quantity']+'x'],''+_0xb07d['id'],''+_0xb07d['quantity']));}}),_0xa5d226['show'](_0x152312)[_0x5ac805(0xc7)](_0x138cf5=>{const _0x6084ff=_0x5ac805;if(_0x138cf5['canceled'])return;if(_0x138cf5[_0x6084ff(0x9e)]===0xd)return gacha(_0x152312);});}function _0x2808(_0x5f0fcd,_0x1af9ed){const _0x3c1167=_0x3c11();return _0x2808=function(_0x280871,_0x4c8df3){_0x280871=_0x280871-0x80;let _0x245b06=_0x3c1167[_0x280871];return _0x245b06;},_0x2808(_0x5f0fcd,_0x1af9ed);}function GC(_0x1d95be){const _0x437152=_0x1b3781,_0x385af6=getScore(_0x437152(0xb7),_0x1d95be);_0x385af6>=pricerare&&(world['scoreboard'][_0x437152(0xa2)](_0x437152(0xb7))[_0x437152(0x91)](_0x1d95be,-pricerare),system[_0x437152(0xb9)](()=>{const _0x482fda=_0x437152,_0x49f392=Math[_0x482fda(0x8f)](Math[_0x482fda(0xa5)]()*prizerare['length']),_0x3f0bce=prizerare[_0x49f392];_0x1d95be[_0x482fda(0xb2)](_0x482fda(0xba)+_0x1d95be[_0x482fda(0xb0)]+'\x20'+_0x3f0bce['id']+'\x20'+_0x3f0bce[_0x482fda(0x96)]),_0x1d95be[_0x482fda(0x90)](_0x482fda(0xae)+_0x1d95be[_0x482fda(0xb0)]+_0x482fda(0x92)+_0x3f0bce[_0x482fda(0x89)]+'.'),_0x1d95be[_0x482fda(0xc4)](_0x482fda(0xad),_0x1d95be['location']),allowchestopen=!![];},0x4b));}