/*

░█████╗░██████╗░░█████╗░████████╗███████╗░██████╗
██╔══██╗██╔══██╗██╔══██╗╚══██╔══╝██╔════╝██╔════╝
██║░░╚═╝██████╔╝███████║░░░██║░░░█████╗░░╚█████╗░
██║░░██╗██╔══██╗██╔══██║░░░██║░░░██╔══╝░░░╚═══██╗
╚█████╔╝██║░░██║██║░░██║░░░██║░░░███████╗██████╔╝
░╚════╝░╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░╚══════╝╚═════╝░

░█████╗░██████╗░██████╗░░█████╗░███╗░░██╗
██╔══██╗██╔══██╗██╔══██╗██╔══██╗████╗░██║
███████║██║░░██║██║░░██║██║░░██║██╔██╗██║
██╔══██║██║░░██║██║░░██║██║░░██║██║╚████║
██║░░██║██████╔╝██████╔╝╚█████╔╝██║░╚███║
╚═╝░░╚═╝╚═════╝░╚═════╝░░╚════╝░╚═╝░░╚══╝                              

➊ 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡
Made by : AjayMC / @ajaytamfan
Version : 1.0
Official Website : www.ajaystudio.xyz
Discord Server : https://discord.com/invite/NNWf2CxtEY
        
➋ 𝗪𝗔𝗥𝗡
    English : Important Reminder Do not copy or plagiarize my additional code. 
    Appreciate other people's work and creativity. Get proper permissions before mixing it with other add-ons. 
    And if you want to translate the addon language into your language and publish it, 
    please provide the name of the original creator and tag the account @ajaytamfan in the description of your video

    Español : Recordatorio importante No copie ni plagie mi código adicional. 
    Apreciar el trabajo y la creatividad de los demás. Obtenga los permisos adecuados antes de mezclarlo con otros complementos. 
    Y si desea traducir el idioma del complemento a su idioma y publicarlo, mencione el nombre del creador original y etiquete la cuenta @ajaytamfan en la descripción de su video.

➌ 𝗛𝗢𝗪 𝗧𝗢 𝗔𝗗𝗗 𝗣𝗥𝗜𝗭𝗘
To add a prize, please follow the template below
    
    {
    displayName: "Diamond Cihuyy", //Display Name Here
    id: "minecraft:diamond", // Items Id Here
    quantity: 5, // Quantity Here
  },
  
  Additional Note: A Maximum Of 21 Prizes Can Be Added
  
  © 2023 - 2023 www.ajaystudio.xyz - All Rights Reserved.
*/

//-------------------------------------Config basic---------------------------------\\
//------------------------------------------Crates-------------------------------------------\\

export const pricebasic = 9999; // Enter Price Here ! 
export const prizebasic = [
  {
    displayName: "Enchant Golden Apple",
    id: "enchanted_golden_apple",
    quantity: 15,
  },
  {
    displayName: "Elytra",
    id: "elytra",
    quantity: 1,
  },
  {
    displayName: "netherite_axe",
    id: "netherite_axe",
    quantity: 1,
  },
  {
    displayName: "Log", //Display Name Here
    id: "minecraft:log", // Items Id Here
    quantity: 100, // Quantity Here
  },
  {
    displayName: "Diamond Cihuyy", //Display Name Here
    id: "minecraft:diamond", // Items Id Here
    quantity: 30, // Quantity Here
  },
];

//-------------------------------------Config rare---------------------------------\\
//------------------------------------------Crates-------------------------------------------\\

export const pricerare = 1000; // Enter Price Here ! 
export const prizerare = [
  {
    displayName: "Enchant Golden Apple",
    id: "enchanted_golden_apple",
    quantity: 15,
  },
  {
    displayName: "Elytra",
    id: "elytra",
    quantity: 1,
  },
  {
    displayName: "netherite_axe",
    id: "netherite_axe",
    quantity: 1,
  },
];


//-----------------------------------Config Super-----------------------------------\\
//----------------------------------------Crates-------------------------------------------\\

export const pricesuper = 1000; // Enter Price Here ! 
export const prizesuper = [
  {
    displayName: "Elytra",
    id: "elytra",
    quantity: 1,
  },
  {
    displayName: "netherite axe",
    id: "netherite_axe",
    quantity: 1,
  },
  {
    displayName: "Diamond Block",
    id: "diamond_block",
    quantity: 10,
  },
  {
    displayName: "Netherite Block",
    id: "netherite_block",
    quantity: 1,
  },
  {
    displayName: "netherite helmet",
    id: "netherite_helmet",
    quantity: 1,
   },
   {
    displayName: "netherite chestplate",
    id: "netherite_chestplate",
    quantity: 1,
  },
  {
    displayName: "Bread",
    id: "bread",
    quantity: 64,
  },
  {
    displayName: "netherite sword",
    id: "netherite_sword",
    quantity: 1,
  },
];




// Do Not Edit The Section Below !! 
import { world, Player, system } from "@minecraft/server";
import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";
import "./type/super.js"
import "./type/basic.js"
import "./type/rare.js"

export function formatNumberWithCommas(number) {
  return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}
export const formattedPriceSuper = formatNumberWithCommas(pricesuper);
export const formattedPriceBasic = formatNumberWithCommas(pricebasic);
export const formattedPriceRare = formatNumberWithCommas(pricerare);
export function getScore(objective, target, useZero = false) {
  try {
    const oB = world.scoreboard.getObjective(objective);
    if (typeof target === 'string') return oB.getScore(oB.getParticipants().find(pT => pT.displayName === target));
    return oB.getScore(target.scoreboardIdentity);
  } catch {
    return useZero ? 0 : NaN;
  }
}